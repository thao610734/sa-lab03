package shop.shopping.integration;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;



@Component
public class CheckoutListener {
	
	  @EventListener
	  public void onCheckoutEvent(CheckoutEvent checkOutEvent) {
		  System.out.println("=============Shoppingcart is checked out at " +
				  checkOutEvent.getDate() + " , total price = " +
				  checkOutEvent.getCart().getTotalPrice());
	  }
}