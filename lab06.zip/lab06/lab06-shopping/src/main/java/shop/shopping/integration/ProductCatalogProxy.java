package shop.shopping.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestOperations;
import shop.shopping.service.dto.product.ProductDTO;

@Component
public class ProductCatalogProxy {

	@Autowired
	private RestOperations restTemplate;

	@Value("${PRODUCT_API}")
	String productsURL;
	
	public ProductDTO getProduct(String productnumber) {
		ProductDTO product = restTemplate.getForObject(productsURL+"/product/" + productnumber, ProductDTO.class);
		return product;
	};
}
