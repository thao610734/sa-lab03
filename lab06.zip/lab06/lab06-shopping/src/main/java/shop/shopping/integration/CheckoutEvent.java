package shop.shopping.integration;

import shop.shopping.domain.ShoppingCart;

import java.util.Date;

public class CheckoutEvent {

	private ShoppingCart cart;
	private Date date= new Date();

	public ShoppingCart getCart() {
		return cart;
	}

	public CheckoutEvent(ShoppingCart cart) {
		this.cart = cart;
	}

	public Date getDate() {
		return date;
	}	
}