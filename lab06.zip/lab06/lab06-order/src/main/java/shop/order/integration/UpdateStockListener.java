package shop.order.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;


@Component
public class UpdateStockListener {

	@Autowired
	JmsTemplate jmsTemplate;

	@EventListener
	public void onProductSold(UpdateStockEvent event) {
		UpdateStockDTO updateStock = new UpdateStockDTO(event.getProductNumber(),event.getQuantity());
		jmsTemplate.convertAndSend("updateStockQueue", updateStock);
	}
}