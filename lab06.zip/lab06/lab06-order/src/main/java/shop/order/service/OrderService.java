package shop.order.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import shop.order.domain.Order;
import shop.order.domain.OrderFactory;
import shop.order.domain.OrderLine;
import shop.order.integration.EmailSender;
import shop.order.integration.OrderConfirmedEvent;
import shop.order.integration.UpdateStockEvent;
import shop.order.repository.OrderRepository;
import shop.order.service.dto.OrderAdapter;
import shop.order.service.dto.OrderCustomerAdapter;
import shop.order.service.dto.OrderDTO;
import shop.order.integration.CustomerProxy;
import shop.order.service.dto.OrderCustomerDTO;
import shop.order.service.dto.shopping.ShoppingCartDTO;


@Service
public class OrderService {
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	CustomerProxy customerService;
	@Autowired
	EmailSender emailSender;

	@Autowired
	private ApplicationEventPublisher publisher;


	public OrderDTO getOrder(String orderNumber) {
		Optional<Order> optOrder = orderRepository.findById(orderNumber);
		if (optOrder.isPresent()) {
			return OrderAdapter.getOrderDTO(optOrder.get());
		} else
			return null;
	}
	
	public void createOrder(ShoppingCartDTO shoppingCartDTO) {
		Order order = OrderFactory.createOrder(shoppingCartDTO);
		orderRepository.save(order);
	}
	
	public void confirm(String orderNumber) {
		Optional<Order> optOrder = orderRepository.findById(orderNumber);
		if (optOrder.isPresent()) {
			Order order= optOrder.get();
			order.confirm();
			emailSender.sendEmail("Thank you for your order with order number "+order.getOrdernumber(), "customer@gmail.com");
			System.out.println("new order with order number "+order.getOrdernumber());

			fireEvents(order);
		} 
	}

	private void fireEvents(Order order) {
		OrderConfirmedEvent orderConfirmedEvent = new OrderConfirmedEvent(OrderAdapter.getOrderDTO(order));
		publisher.publishEvent(orderConfirmedEvent);

		for (OrderLine orderline : order.getOrderlineList()) {
			UpdateStockEvent updateStockEvent = new UpdateStockEvent(orderline.getProduct().getProductnumber(),
					orderline.getQuantity());
			publisher.publishEvent(updateStockEvent);
		}
	}

	public void setCustomer(String orderNumber, String customerNumber) {
		Optional<Order> optOrder = orderRepository.findById(orderNumber);
		if (optOrder.isPresent()) {
			Order order = optOrder.get();
			OrderCustomerDTO customerDTO = customerService.getOrderCustomer(customerNumber);
			if(customerDTO!=null) {
				order.setCustomer(OrderCustomerAdapter.getCustomer(customerDTO));
			}
			orderRepository.save(order);
		}		
	}

}
