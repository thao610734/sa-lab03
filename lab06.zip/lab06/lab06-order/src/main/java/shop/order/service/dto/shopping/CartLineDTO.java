package shop.order.service.dto.shopping;

import shop.order.service.dto.product.ProductDTO;

public class CartLineDTO {
	int quantity;
	ProductDTO product;

	public ProductDTO getProduct() {
		return product;
	}

	public void setProduct(ProductDTO product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
