package shop.products.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import shop.products.domain.Stock;
import shop.products.service.ProductCatalogService;

@Component
public class UpdateStockMessageListener {

	@Autowired
	ProductCatalogService productCatalogService;

	@JmsListener(destination="updateStockQueue")
	public void receiveMessage(final UpdateStockDTO updateStock) {
		Stock stock = productCatalogService.getStock(updateStock.getProductNumber());
		int newQuantity = stock.getQuantity() - updateStock.getQuantity();
		if (newQuantity <= 0)
			newQuantity = 0;
		productCatalogService.setStock(updateStock.getProductNumber(), newQuantity, stock.getLocationcode());
		System.out.println("Quantity of product " + updateStock.getProductNumber() + " is updated to " + newQuantity);
	}
}