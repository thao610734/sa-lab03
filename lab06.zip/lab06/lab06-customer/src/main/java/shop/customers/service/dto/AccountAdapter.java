package shop.customers.service.dto;

import shop.customers.domain.Account;
import shop.customers.service.dto.AccountDTO;

public class AccountAdapter {

	public static Account getAccount(AccountDTO accountDTO) {
		Account creditcard = new Account(
				accountDTO.getAccountNumber(),
				accountDTO.getUsername(),
				accountDTO.getPassword()
				);		
		return creditcard;				
	}
	
	public static AccountDTO getAccountDTO(Account account) {
		AccountDTO accountDTO = new AccountDTO(
				account.getAccountNumber(),
				account.getUsername(),
				account.getPassword()
				);		
		return accountDTO;				
	}
}
