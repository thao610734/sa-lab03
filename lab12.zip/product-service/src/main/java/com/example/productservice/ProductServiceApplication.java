package com.example.productservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@SpringBootApplication
@RestController
public class ProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApplication.class, args);
	}

	@Bean
	public OAuth2RestTemplate oAuth2RestTemplate(OAuth2ClientContext oAuth2ClientContext, OAuth2ProtectedResourceDetails details) {
		return new OAuth2RestTemplate(details, oAuth2ClientContext);
	}

	@GetMapping("/products")
	public List<String> getProducts() {
		return Arrays.asList("Apple", "Banana", "Cherry");
	}

	@Autowired
	OAuth2RestTemplate restTemplate;

	@GetMapping("/employee")
	public String getEmployee() {
		return restTemplate.getForObject("http://localhost:8082/employee-info", String.class);
	}

	@GetMapping("/salary")
	public String getSalary() {
		return restTemplate.getForObject("http://localhost:8083/salary-info", String.class);
	}

}
