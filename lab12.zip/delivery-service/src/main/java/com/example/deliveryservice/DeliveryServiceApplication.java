package com.example.deliveryservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;

@SpringBootApplication
public class DeliveryServiceApplication {

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Value(value = "${app.topic.shopping}")
	private String topic;

	public static void main(String[] args) {
		SpringApplication.run(DeliveryServiceApplication.class, args);
	}

	@KafkaListener(topics = "${app.topic.shopping}")
	public void receive(@Payload String message,
						@Headers MessageHeaders headers) {
		try {
			Event<Order> orderEvent = objectMapper.readValue(message,  new TypeReference<Event<Order>>(){});
			if ("ORDER_PREPARED_EVENT".equals(orderEvent.getType())) {
				System.out.println("received message= "+ message);
				headers.keySet().forEach(key -> System.out.println(key+" : "+ headers.get(key)));
				sendEvent(orderEvent);
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

	}

	private void sendEvent(Event<Order> orderEvent) throws JsonProcessingException {
		orderEvent.setType("ORDER_DELIVERED_EVENT");
		orderEvent.getPayload().setTrackingId("tracking" + System.currentTimeMillis());
		String message = objectMapper.writeValueAsString(orderEvent);
		kafkaTemplate.send(topic, message);
		System.out.println("sending message = " + message + " to topic="+ topic);
	}

}

@Data
@Builder
@ToString @AllArgsConstructor @NoArgsConstructor
class Order {
	private String orderNo;
	private String product;
	private String customerId;
	private double amount;
	private String status;
	private String tx;
	private String trackingId;
}

@Data
@Builder
@ToString @AllArgsConstructor @NoArgsConstructor
class Event<T> {
	private String type;
	private T payload;
}
