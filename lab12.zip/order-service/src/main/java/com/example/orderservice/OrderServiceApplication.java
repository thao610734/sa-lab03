package com.example.orderservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
@RestController
@Log4j2
public class OrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceApplication.class, args);
	}

	static Map<String, Order> dbOrders;
	static {
		dbOrders = new HashMap<>();
		dbOrders.put("001", Order.builder().orderNo("001").product("Apple").amount(5).customerId("Peter").status("new").build());
		dbOrders.put("002", Order.builder().orderNo("002").product("Banana").amount(3).customerId("Jame").status("new").build());
		dbOrders.put("003", Order.builder().orderNo("003").product("Cheery").amount(1).customerId("Bond").status("new").build());
	}

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Value(value = "${app.topic.shopping}")
	private String topic;

	@Autowired
	ObjectMapper objectMapper;

	@GetMapping("/process/{orderNo}")
	public String createOrder(@PathVariable String orderNo) {

		Event<Order> orderEvent = Event.<Order>builder()
				.type("ORDER_CREATED_EVENT").payload(dbOrders.get(orderNo))
				.build();

		try {
			String message = objectMapper.writeValueAsString(orderEvent);
			kafkaTemplate.send(topic, message);
			System.out.println("sending message = " + message + " to topic="+ topic);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		return "Done";
	}

	@KafkaListener(topics = "${app.topic.shopping}")
	public void receive(@Payload String message,
						@Headers MessageHeaders headers) {
		try {
			Event<Order> orderEvent = objectMapper.readValue(message, new TypeReference<Event<Order>>(){});
			if ("ORDER_DELIVERED_EVENT".equals(orderEvent.getType())) {
				System.out.println("received message= "+ message);
				headers.keySet().forEach(key -> System.out.println(key+" : "+ headers.get(key)));
				dbOrders.get(orderEvent.getPayload().getOrderNo()).setStatus("Completed");
				System.out.println("Success! " + orderEvent);
			} else if ("PRODUCT_OUT_OF_STOCK_EVENT".equals(orderEvent.getType())) {
				System.out.println("received message= "+ message);
				headers.keySet().forEach(key -> System.out.println(key+" : "+ headers.get(key)));
				dbOrders.get(orderEvent.getPayload().getOrderNo()).setStatus("Cancelled");
				System.out.println("Failure! " + orderEvent);
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}
}

@Data
@Builder
@ToString @AllArgsConstructor @NoArgsConstructor
class Order {
	private String orderNo;
	private String product;
	private String customerId;
	private double amount;
	private String status;
	private String tx;
	private String trackingId;
}

@Data
@Builder
@ToString @AllArgsConstructor @NoArgsConstructor
class Event<T> {
	private String type;
	private T payload;
}


