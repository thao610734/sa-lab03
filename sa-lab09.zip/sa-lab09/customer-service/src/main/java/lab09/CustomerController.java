package lab09;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

    @Autowired
    AccountFeignClient accountFeignClient;

    @GetMapping("/customer/{customerId}")
    public Account getAccount(@PathVariable("customerId") String customerId) {
        return accountFeignClient.getAccount(customerId);
    }

    @FeignClient("AccountService")
    @RibbonClient(name = "AccountService")
    interface AccountFeignClient {
        @GetMapping("/account/{customerId}")
        Account getAccount(@PathVariable("customerId") String customerId);
    }
}
