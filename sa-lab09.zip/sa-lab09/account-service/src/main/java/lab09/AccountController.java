/*
package lab09;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {

    @GetMapping("/account/{customerId}")
    public Account getAccount(@PathVariable("customerId") String customerId) {
        return new Account("1234", "1000.00");
    }
}
*/