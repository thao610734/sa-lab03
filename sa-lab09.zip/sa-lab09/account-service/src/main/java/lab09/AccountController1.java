package lab09;

import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Profile("one")
public class AccountController1 {

    @GetMapping("/account/{customerId}")
    public Account getAccount(@PathVariable("customerId") String customerId) {
        System.out.println("AccountController1 is called");
        return new Account("1234", "1000.00");
    }
}
