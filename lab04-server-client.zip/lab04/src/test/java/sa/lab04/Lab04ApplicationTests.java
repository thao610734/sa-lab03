package sa.lab04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
