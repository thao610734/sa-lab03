package sa.lab04.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import sa.lab04.domain.product.Product;

public interface ProductRepository extends MongoRepository<Product, String> {
}
