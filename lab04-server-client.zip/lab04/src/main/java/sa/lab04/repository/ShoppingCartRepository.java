package sa.lab04.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import sa.lab04.domain.shopping.ShoppingCart;

public interface ShoppingCartRepository extends MongoRepository<ShoppingCart, String> {
}
