package sa.lab04.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sa.lab04.domain.shopping.Product;
import sa.lab04.domain.shopping.CartLine;
import sa.lab04.domain.shopping.ShoppingCart;
import sa.lab04.repository.ProductRepository;
import sa.lab04.repository.ShoppingCartRepository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ShoppingService{

    private final ShoppingCartRepository cartRepository;
    private final ProductRepository productRepository;
    private final OrderService orderService;

    public void addToCart(String cartId, String productnumber, int quantity) {
        sa.lab04.domain.product.Product productInStore = productRepository.findById(productnumber).get();
        if (productInStore == null) return;
        Product product = new Product(productInStore.getProductNumber(), productInStore.getDescription(),
                productInStore.getPrice());
        ShoppingCart cart = getCart(cartId);
        if (cart == null) {
            cart = new ShoppingCart();
            cart.setCartId(cartId);
            cart.setCreatedAt(LocalDateTime.now());
            List<CartLine> details = new ArrayList<>();
            details.add(new CartLine(product, quantity));
            cart.setDetails(details);
        } else {
            Optional<CartLine> p = cart.getDetails().stream()
                    .filter(e -> e.getProduct().getProductNumber().equals(productnumber))
                    .findFirst();
            if (p.isPresent()) {
                p.get().setQuantity(p.get().getQuantity() + quantity);
            } else {
                cart.getDetails().add(new CartLine(product, quantity));
            }
        }
        cartRepository.save(cart);
    }

    public ShoppingCart getCart(String cartId) {
        Optional<ShoppingCart> cart = cartRepository.findById(cartId);
        if (cart.isPresent()) return cart.get();
        return null;
    }

    public void checkout(String cartId) {
        Optional<ShoppingCart> cart = cartRepository.findById(cartId);
        if (cart.isPresent()) {
            orderService.createOrder(cart.get());
        }
    }
}
