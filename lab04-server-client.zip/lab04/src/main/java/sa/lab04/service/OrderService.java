package sa.lab04.service;

import java.util.Optional;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sa.lab04.domain.order.Order;
import sa.lab04.domain.order.OrderFactory;
import sa.lab04.domain.shopping.ShoppingCart;
import sa.lab04.repository.OrderRepository;

@Service
@RequiredArgsConstructor
public class OrderService {


	private final OrderRepository orderRepository;

	public Order getOrder(String orderNumber) {
		Optional<Order> optOrder = orderRepository.findById(orderNumber);
		if (optOrder.isPresent()) {
			return optOrder.get();
		} else
			return null;
	}
	
	public void createOrder(ShoppingCart cart) {
		Order order = OrderFactory.createOrder(cart);
		orderRepository.save(order);
	}

}
