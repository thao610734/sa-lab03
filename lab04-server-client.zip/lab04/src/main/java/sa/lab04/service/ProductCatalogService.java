package sa.lab04.service;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sa.lab04.domain.product.Product;
import sa.lab04.domain.product.Stock;
import sa.lab04.repository.ProductRepository;

@Service
@RequiredArgsConstructor
public class ProductCatalogService {

    private final ProductRepository productRepository;


    public void addProduct(String productnumber, String description, double price) {
        productRepository.save(new Product(productnumber, description, price, null));
    }


    public Product getProduct(String productnumber) {
        return productRepository.findById(productnumber).get();
    }


    public void setStock(String productnumber, int quantity, String locationcode) {
        Product product = getProduct(productnumber);
        if (product != null) {
            product.setStockInfo(new Stock(quantity, locationcode));
            productRepository.save(product);
        }
    }
}
