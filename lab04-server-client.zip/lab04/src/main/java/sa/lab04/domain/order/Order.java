package sa.lab04.domain.order;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document
public class Order {
	@Id
	private String orderNumber;
	private LocalDate date;
	private String status;

	private ArrayList<OrderLine> orderLines = new ArrayList<>();

	public void addOrderLine(OrderLine line) {
		orderLines.add(line);
	}

}
