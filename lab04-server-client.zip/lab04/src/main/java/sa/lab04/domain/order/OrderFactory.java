package sa.lab04.domain.order;

import sa.lab04.domain.shopping.CartLine;
import sa.lab04.domain.shopping.ShoppingCart;

import java.time.LocalDate;

public class OrderFactory {
	
	public static Order createOrder(ShoppingCart cart) {
		Order order = new Order();
		order.setOrderNumber(cart.getCartId());
		order.setDate(LocalDate.now());
		order.setStatus("PLACED");
		for (CartLine cline : cart.getDetails()) {
			OrderLine line = new OrderLine();
			Product product = new Product(cline.getProduct().getProductNumber(), cline.getProduct().getDescription(), cline.getProduct().getPrice());
			line.setProduct(product);
			line.setQuantity(cline.getQuantity());
			order.addOrderLine(line);
		}
		return order;
	}
}
