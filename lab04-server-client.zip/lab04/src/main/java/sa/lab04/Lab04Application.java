package sa.lab04;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import sa.lab04.domain.product.Product;
import sa.lab04.repository.OrderRepository;
import sa.lab04.repository.ProductRepository;
import sa.lab04.repository.ShoppingCartRepository;

@SpringBootApplication
public class Lab04Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab04Application.class, args);
	}

	@Bean
	public CommandLineRunner populateData(ProductRepository productRepository,
										  ShoppingCartRepository shoppingCartRepository,
										  OrderRepository orderRepository) {
		return args -> {

			productRepository.deleteAll();
			shoppingCartRepository.deleteAll();
			orderRepository.deleteAll();

			productRepository.save(new Product("001", "Tomato 1b", 1.2, null));
			productRepository.save(new Product("002", "Carrot 1b", 1.8, null));
			productRepository.save(new Product("003", "Cabbage", 2.3, null));
			productRepository.save(new Product("004", "Egg 12", 3.2, null));
			productRepository.save(new Product("005", "Potato 1b", 4.5, null));
		};
	}

}
