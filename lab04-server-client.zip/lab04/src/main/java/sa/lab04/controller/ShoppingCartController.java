package sa.lab04.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sa.lab04.domain.shopping.ShoppingCart;
import sa.lab04.service.ShoppingService;

@RestController
@RequestMapping("/cart")
@RequiredArgsConstructor
public class ShoppingCartController {

    private final ShoppingService shoppingService;

    @GetMapping("/{cartId}")
    public ResponseEntity<?> getCart(@PathVariable String cartId) {
        ShoppingCart cart = shoppingService.getCart(cartId);
        if (cart != null)
            return new ResponseEntity<>(cart, HttpStatus.OK);
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping("/{cartId}/{pNumber}/{qty}")
    public ResponseEntity<?> addToCart(@PathVariable String cartId,
                                       @PathVariable String pNumber,
                                       @PathVariable int qty) {
        shoppingService.addToCart(cartId, pNumber, qty);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping(value = "/checkout/{cartId}")
    public ResponseEntity<?> checkoutCart(@PathVariable String cartId) {
        shoppingService.checkout(cartId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
