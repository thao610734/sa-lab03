package sa.lab04.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import sa.lab04.domain.order.Order;
import sa.lab04.service.OrderService;


@RestController @RequiredArgsConstructor
public class OrderController {

	private final OrderService orderService;
	
	@GetMapping("/order/{orderNumber}")
	public ResponseEntity<?> getCart(@PathVariable String orderNumber) {
		Order order = orderService.getOrder(orderNumber);
		return new ResponseEntity<>(order, HttpStatus.OK);
	}
	
}
