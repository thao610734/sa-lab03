package sa.lab04client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Lab04clientApplication implements CommandLineRunner {

	@Autowired
	private RestOperations restTemplate;

	private final static String API = "http://localhost:8080";

	public static void main(String[] args) {
		SpringApplication.run(Lab04clientApplication.class, args);
	}

	@Bean
	RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		return restTemplate;
	}

	@Override
	public void run(String... args) throws Exception {

		restTemplate.postForObject(API + "/cart/order1/001/3", null, String.class);
		restTemplate.postForObject(API + "/cart/order1/002/2", null, String.class);
		restTemplate.postForObject(API + "/cart/order1/003/1", null, String.class);

		restTemplate.postForObject(API + "/cart/checkout/order1", null, String.class);

		String order = restTemplate.getForObject(API + "/order/order1", String.class);
		System.out.println(order);

	}

}
