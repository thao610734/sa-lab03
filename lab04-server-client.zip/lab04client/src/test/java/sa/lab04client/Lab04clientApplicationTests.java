package sa.lab04client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab04clientApplicationTests {

	@Test
	void contextLoads() {
	}

}
