package integration.ex1;

import java.io.Serializable;

public class Order implements Serializable {

    private String orderNumber;
    private double amount;

    public Order() {}

    public Order(String on, double a) {
        this.amount = a;
        this.orderNumber = on;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderNumber='" + orderNumber + '\'' +
                ", amount=" + amount +
                '}';
    }
}
