package integration.ex1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PremiumShippingService {

    private static final Logger LOG = LoggerFactory.getLogger(PremiumShippingService.class);

    public String shipping(Order order) throws Exception {
        LOG.info("Order {} on the premium delivery", order.getOrderNumber());
        return "Completed - Next day";
    }
}
