package integration.ex1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired
    private OrderGateway gateway;

    @RequestMapping("/order/{orderNumber}/{amount}")
    public String sendOrder(@PathVariable("orderNumber") String orderNumber,
                            @PathVariable("amount") double amount) {
        Message<Order> orderMessage =  MessageBuilder.withPayload(new Order(orderNumber, amount)).build();

        String result = gateway.handleRequest(orderMessage);
        return result;
    }

}
