package integration.ex1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NormalShippingService {

    private static final Logger LOG = LoggerFactory.getLogger(NormalShippingService.class);

    public String shipping(Order order) throws Exception {
        LOG.info("Order {} on the normal delivery", order.getOrderNumber());
        return "Completed - in 3 days";
    }
}
