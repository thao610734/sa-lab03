package integration.ex1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShippingService {

    private static final Logger LOG = LoggerFactory.getLogger(ShippingService.class);

    public String shipping(Order order) throws Exception {
        LOG.info("Order {} on the delivery", order.getOrderNumber());
        return "Completed";
    }
}
