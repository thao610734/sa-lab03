package integration.ex1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WarehouseService {

    private static final Logger LOG = LoggerFactory.getLogger(WarehouseService.class);

    public Order updateStock(Order order) throws Exception {
        LOG.info("Order {} updated stock", order.getOrderNumber());
        return order;
    }
}
