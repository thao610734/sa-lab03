package integration.ex1;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.Message;

@MessagingGateway
public interface OrderGateway {

    @Gateway(requestChannel = "inputChannel.warehouse")
    String handleRequest(Message<Order> message);

}
