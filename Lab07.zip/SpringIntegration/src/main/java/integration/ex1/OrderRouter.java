package integration.ex1;

public class OrderRouter {

    public String route(Order order) {
        return order.getAmount() > 175 ? "inputChannel.premium" : "inputChannel.normal";
    }
}
