package integration.ex2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DHLService {

    private static final Logger LOG = LoggerFactory.getLogger(DHLService.class);

    public String shipping(Order order) throws Exception {
        LOG.info("DHL ship order {} total {}", order.getOrderNumber(), order.getTotal());
        return "DHL on delivery";
    }
}
