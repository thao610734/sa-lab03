package integration.ex2;

public class ShippingRouter {

    public String route(Order order) {
        return order.isDomestic()? "domestic" : "international";
    }
}


