package integration.ex2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PlaceOrderService {

    private static final Logger LOG = LoggerFactory.getLogger(PlaceOrderService.class);

    public String rejectOrder(Order order) throws Exception {
        LOG.info("Reject order {} total {}", order.getOrderNumber(), order.getTotal());
        return "Reject order";
    }

    public String sendRequestSupplier(Order order) throws Exception {
        LOG.info("Request supplier: order {} total {}", order.getOrderNumber(), order.getTotal());
        return "Run out of stock, send request to Supplier";
    }

    public String paymentFail(Order order) throws Exception {
        LOG.info("Payment fail: order {} total {}", order.getOrderNumber(), order.getTotal());
        return "Payment fail, set order status NO_FULFILLMENT";
    }

}
