package integration.ex2;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.Message;

@MessagingGateway
public interface PlaceOrderGateway {

    @Gateway(requestChannel = "newOrder")
    String handleRequest(Message<Order> message);

}
