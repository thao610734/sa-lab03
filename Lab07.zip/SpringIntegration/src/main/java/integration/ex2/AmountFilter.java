package integration.ex2;

public class AmountFilter {

    public boolean checkAmount(Order order) {
        return order.getTotal() >= 1;
    }
}
