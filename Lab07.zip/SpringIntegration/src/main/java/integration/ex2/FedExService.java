package integration.ex2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FedExService {

    private static final Logger LOG = LoggerFactory.getLogger(FedExService.class);

    public String shipping(Order order) throws Exception {
        LOG.info("FedEx ship order {} total {}", order.getOrderNumber(), order.getTotal());
        return "FedEx on delivery";
    }
}
