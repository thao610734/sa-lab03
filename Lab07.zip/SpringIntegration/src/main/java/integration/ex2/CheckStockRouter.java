package integration.ex2;

public class CheckStockRouter {

    StockService stockService;

    public String route(Order order) {
        return stockService.checkStock(order)? "paymentChanel" : "supplierChannel";
    }
}

class StockService {

    public boolean checkStock(Order order) {
        long count = order.getOrderLines().stream().map(OrderLine::getQuantity).count();
        return count > 20;
    }
}
