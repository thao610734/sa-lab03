package integration.ex2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PlaceOrderController {

    @Autowired
    private PlaceOrderGateway gateway;

    @RequestMapping("/place-order")
    public String sendOrder(@RequestBody Order order) {
        Message<Order> orderMessage =  MessageBuilder.withPayload(order).build();
        String result = gateway.handleRequest(orderMessage);
        return result;
    }

}
