package integration.ex2;

import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {
    private String orderNumber;
    private double total;
    private boolean domestic;
    private List<OrderLine> orderLines;

    public Order() {}

    public Order(String orderNumber, double total, boolean domestic, List<OrderLine> orderLines) {
        this.orderNumber = orderNumber;
        this.total = total;
        this.domestic = domestic;
        this.orderLines = orderLines;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public boolean isDomestic() {
        return domestic;
    }

    public void setDomestic(boolean domestic) {
        this.domestic = domestic;
    }

    public List<OrderLine> getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(List<OrderLine> orderLines) {
        this.orderLines = orderLines;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderNumber='" + orderNumber + '\'' +
                ", total=" + total +
                ", domestic=" + domestic +
                ", orderLines=" + orderLines +
                '}';
    }
}
