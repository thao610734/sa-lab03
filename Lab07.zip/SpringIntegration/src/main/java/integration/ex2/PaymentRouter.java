package integration.ex2;

public class PaymentRouter {

    PaymentService paymentService;

    public String route(Order order) {
        return paymentService.processPayement(order)? "paySuccess" : "payFail";
    }
}

class PaymentService {

    public boolean processPayement(Order order) {
        return order.getTotal() > 10_000;
    }
}
