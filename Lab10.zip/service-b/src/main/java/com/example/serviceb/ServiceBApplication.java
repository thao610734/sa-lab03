package com.example.serviceb;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableCircuitBreaker
public class ServiceBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceBApplication.class, args);
	}

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

}

@RestController
class ServiceBController {

	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/text")
	@HystrixCommand(fallbackMethod = "getTextFallback")
	public String getText() {
		String result = restTemplate.getForObject("http://localhost:7072/text", String.class);
		return result + " Sleuth + Zipkin";
	}

	public String getTextFallback() {
		return "Text from service B under constructor";
	}
}
