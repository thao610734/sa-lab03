package com.example.lab11;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.util.function.Tuple2;

import java.time.Duration;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Stream;

@SpringBootApplication
@RestController
public class SaLab11ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaLab11ServerApplication.class, args);
	}

	@GetMapping(value = "/stock/{symbol}")
	public Flux<Stock> getTemperature(@PathVariable String symbol) {
		Flux<Stock> eventFlux =	Flux.fromStream(Stream.generate(() -> new Stock(symbol,
				ThreadLocalRandom.current().nextDouble(35), new Date()))
				.peek(System.out::println));
		Flux<Long> durationFlux = Flux.interval(Duration.ofSeconds(2));
		return Flux.zip(eventFlux, durationFlux).map(Tuple2::getT1);
	}

}

@AllArgsConstructor
@Data
class Stock {
	private String symbol;
	private Double price;
	private Date date;
}



