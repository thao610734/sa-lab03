package com.example.lab11;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Collections;
import java.util.Date;

@SpringBootApplication @Slf4j
public class Lab11ClientApplication {

	public static void main(String[] args) {
		new SpringApplicationBuilder(Lab11ClientApplication.class)
				.properties(Collections.singletonMap("server.port", "8081"))
				.run(args);
	}

	@Bean
	WebClient client() {
		return WebClient.create("http://localhost:8080");
	}

	@Bean
	CommandLineRunner demo(WebClient client) {
		return args -> {
				client.get()
						.uri("/stock/yzz")
						.accept(MediaType.TEXT_EVENT_STREAM)
						.exchange()
						.flatMapMany(s -> s.bodyToFlux(Stock.class))
						.subscribe(System.out::println);
        };

	}
}

@Data
class Stock {
	private String symbol;
	private Double price;
	private Date date;
}



