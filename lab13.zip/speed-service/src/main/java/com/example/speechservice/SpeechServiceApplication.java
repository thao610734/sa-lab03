package com.example.speechservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class SpeechServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeechServiceApplication.class, args);
	}

	@Autowired
	SpeedCalculator speedCalculator;

	@KafkaListener(topics = "${app.topic.camera1}")
	public void receive1(@Payload String message,
						@Headers MessageHeaders headers) throws JsonProcessingException {
		speedCalculator.handleRecord(message);
	}

	@KafkaListener(topics = "${app.topic.camera2}")
	public void receive2(@Payload String message,
						@Headers MessageHeaders headers) throws JsonProcessingException {
		speedCalculator.handleRecord(message);
	}

}

@Component
class SpeedCalculator {

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Value(value = "${app.topic.tofasttopic}")
	private String topic;

	@Autowired
	ObjectMapper objectMapper;

	private Map<String, SensorRecord> recordstream = new HashMap<>();

	public void handleRecord(String messageSensorRecord) throws JsonProcessingException{

		SensorRecord sensorRecord = objectMapper.readValue(messageSensorRecord, SensorRecord.class);

		int speed=0;
		int time=1000;
		if (sensorRecord.getCameraId()== 1) {
			recordstream.put(sensorRecord.getLicencePlate(), sensorRecord);
		}
		if (sensorRecord.getCameraId()== 2) {
			SensorRecord sensorRecord1 = recordstream.get(sensorRecord.getLicencePlate());
			if (sensorRecord1 != null) {
				if (sensorRecord1.getMinute() == sensorRecord.getMinute()) {
					time = sensorRecord.getSecond()-sensorRecord1.getSecond();
				}
				else if ((sensorRecord.getMinute() - sensorRecord1.getMinute()) == 1) {
					time = (sensorRecord.getSecond()+60) -sensorRecord1.getSecond();
				}
				speed = (int) ((0.5 / time)*3600);

				recordstream.remove(sensorRecord.getLicencePlate());
				if (speed >72) {
					System.out.println("speeding ********"+ sensorRecord.getLicencePlate()+" = "+ speed);

						String message = objectMapper.writeValueAsString(
								SpeedRecord.builder()
										.licencePlate(sensorRecord.getLicencePlate())
										.speed(speed)
										.build()
						);
						kafkaTemplate.send(topic, message);


				}
			}
		}
	}

}
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
class SpeedRecord {
	private String licencePlate;
	private int speed;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
class SensorRecord {
	private String licencePlate;
	private int minute;
	private int second;
	private int cameraId;
}
