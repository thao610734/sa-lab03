package com.example.trafficsensor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrafficSensorApplicationTests {

	@Test
	void contextLoads() {
	}

}
