package com.example.trafficsensor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class TrafficSensorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrafficSensorApplication.class, args);
	}

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Value(value = "${app.topic.camera}")
	private String topic;

	@Autowired
	ObjectMapper objectMapper;

	@GetMapping("/{cameraId}/{licencePlate}/{minute}/{second}")
	public String send(@PathVariable int cameraId,
					   @PathVariable String licencePlate,
					   @PathVariable int minute,
					   @PathVariable int second) {
		try {
			String message = objectMapper.writeValueAsString(SensorRecord.builder()
					.licencePlate(licencePlate).cameraId(cameraId).minute(minute).second(second)
					.build());
			kafkaTemplate.send(topic + cameraId, message);
			System.out.println("sending message = " + message + " to topic="+ topic);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return "ok";
	}

}

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class SensorRecord {
	private String licencePlate;
	private int minute;
	private int second;
	private int cameraId;
}
