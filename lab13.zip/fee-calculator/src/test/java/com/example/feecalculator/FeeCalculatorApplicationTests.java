package com.example.feecalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeeCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
