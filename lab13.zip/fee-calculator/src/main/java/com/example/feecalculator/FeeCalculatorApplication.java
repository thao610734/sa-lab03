package com.example.feecalculator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;

@SpringBootApplication
@Log4j2
public class FeeCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeeCalculatorApplication.class, args);
	}

	@Autowired
	ObjectMapper objectMapper;

	@KafkaListener(topics = "${app.topic.tofasttopic}")
	public void receive(@Payload String message,
						 @Headers MessageHeaders headers) throws JsonProcessingException {
		SpeedRecord record = objectMapper.readValue(message, SpeedRecord.class);
		log.info("Car " + record.getLicencePlate() + " has speed " + record.getSpeed() + " fee: "
				+ getFee(record.getSpeed()));
	}

	private int getFee(int speed) {
		return speed < 77 ? 25 : speed < 82 ? 45 : speed < 90 ? 80 : 125;
	}

}

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
class SpeedRecord {
	private String licencePlate;
	private int speed;
}
